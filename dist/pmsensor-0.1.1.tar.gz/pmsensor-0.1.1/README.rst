psensor - Library for particulate matter sensors
================================================

This library lets you read sensor data from serial-connected particulate matter sensors. Currently it supports the following sensors:

- OneAir A3
- Nova Fitness SDS021

